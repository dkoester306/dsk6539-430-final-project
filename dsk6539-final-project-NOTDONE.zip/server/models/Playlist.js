const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
const _ = require('underscore');

let PlaylistModel = {};
const convertId = mongoose.Types.ObjectId;

const PlaylistEntrySchema = new mongoose.Schema({
    title: String,
    artist: String,
    album: String,
    link: String,
    img: String,
    id: String,
});


const PlaylistSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    tracks: [PlaylistEntrySchema],
    owner: {
        type: mongoose.Schema.ObjectId,
        required: true,
        ref: 'Playlist'
    },
    createdDate: {
        type: Date,
        default: Date.now,
    }
});

PlaylistModel = mongoose.model('playlist', PlaylistSchema);



module.exports.PlaylistModel = PlaylistModel;
module.exports.PlaylistSchema = PlaylistSchema;